<?php $__env->startSection('position'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">افزودن دارایی</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="<?php echo e(route('adminPanel')); ?>">خانه</a></li>
                <li class="breadcrumb-item active">افزودن دارایی</li>
            </ol>
        </div><!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .dt-buttons {
            float: left;
            padding: 10px;
        }

        .dt-buttons button {
            margin: 3px;
        }
    </style>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">افزودن دارایی غیر نقدی
                    </h3>

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('resource.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="other">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="chilename" class="col-form-label text-right">عنوان :</label>
                                    <input type="text" required class="form-control" id="chilename"
                                           name="title">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group pt-2">
                                    <label for="exampleFormControlSelect1" class=" text-right">خیر :</label>
                                    <select class="form-control text-left" id="exampleFormControlSelect1" name="donator"
                                            style="direction: ltr">
                                        <?php $__currentLoopData = \App\Models\Donator::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($l->id); ?>"><?php echo e($l->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group w-100">
                                <label for="status" class="col-form-label text-right">توضیحات :</label>
                                <textarea class="form-control w-100"  id="status" name="description" required></textarea>
                            </div>
                        </div>
                        <div class="col-2">
                            <button type="submit" class="btn btn-primary">ذخیره</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mrgod\Desktop\ponisha\hamdeli\resources\views/admin/resource/create/other.blade.php ENDPATH**/ ?>