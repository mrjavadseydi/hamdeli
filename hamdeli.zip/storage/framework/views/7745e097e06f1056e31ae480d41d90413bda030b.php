<?php $__env->startSection('position'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">نمایش نیازمند</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="<?php echo e(route('adminPanel')); ?>">خانه</a></li>
                <li class="breadcrumb-item active"> نمایش نیازمند</li>
            </ol>
        </div><!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .dt-buttons {
            float: left;
            padding: 10px;
        }

        .dt-buttons button {
            margin: 3px;
        }
    </style>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title d-inline">نمایش نیازمند
                    </h3>
                    <div class="text-left  d-inline" style="float: left">
                        <button type="button" class="btn btn-sm btn-danger trashbtn" data-id="<?php echo e($user->id); ?>">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            نام :
                            <?php echo e($user->name); ?>

                        </div>
                        <div class="col-md-4">
                            <?php if($user->is_iranian): ?>
                                کد اتباع :
                            <?php else: ?>
                                کد ملی :
                            <?php endif; ?>
                            <?php echo e($user->person_id); ?>

                        </div>
                        <div class="col-md-4">
                            تلفن :
                            <?php echo e($user->mobile); ?>

                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            آدرس :
                            <?php echo e($user->address); ?>

                        </div>
                        <div class="col-md-6">
                            اطلاعات بانکی :
                            <?php echo e($user->bank_info); ?>

                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        وضعیت :
                        <?php echo e($user->status); ?>

                    </div>
                    <hr>
                    <div class="row">
                        وضعیت سرپرست خانوار :
                        <?php echo e($user->leader_status); ?>

                    </div>
                    <hr>
                    <div class="row">
                        معرف :
                        <?php echo e($user->introduc); ?>

                    </div>
                    <?php $__currentLoopData = \App\Models\ChildNeedy::whereNeedieId($user->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                نام فرد تحت تکلف شماره <?php echo e($l+1); ?>:
                                <?php echo e($item->name); ?>

                            </div>
                            <div class="col-md-6">
                                <?php if($user->is_iranian): ?>
                                    کد اتباع  تحت تکلف شماره <?php echo e($l+1); ?>:
                                <?php else: ?>
                                    کد ملی  تحت تکلف شماره <?php echo e($l+1); ?>:
                                <?php endif; ?>
                                <?php echo e($item->person_id); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            تعداد دفعات دریافت  :
                            <?php echo e(\App\Models\SendNeedy::whereNeedieId($user->id)->count()); ?>

                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            لیست اهدا :
                            <ul>
                                <?php $__currentLoopData = \App\Models\SendNeedy::whereNeedieId($user->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('send.show',$l->send_id)); ?>" target="_blank">
                                    اهدا  شماره <?php echo e($l->send_id); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('plugin/sweetalert.js')); ?>"></script>
    <script>
        $(document).on('click', '.trashbtn', function (e) {
            let _token = $('div[name="destroy"]').attr('content');
            e.preventDefault();
            var id = $(this).data('id');
            Swal.fire({
                title: 'آیا  اطمینان دارید ؟',
                text: "آیا از حذف این رکورد اطمینان دارید ؟ این دیتا قابل بازیابی نخواهد بود !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: "خیر منصرف شدم!",
                confirmButtonText: 'بله !'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('needy.delete')); ?>",
                        data: {id: id, _token: _token},
                        success: function (data) {
                            Swal.fire({
                                position: 'top-end',
                                icon: 'success',
                                title: 'حذف رکورد از دیتابیس با موفقیت انجام شد !',
                                showConfirmButton: false,
                                timer: 1500
                            })
                            setTimeout(function () {
                                window.location.reload();
                            }, 1800);

                        }
                    });
                }
            })
            // function() {
            //
            // });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mrgod\Desktop\ponisha\hamdeli\resources\views/admin/needy/show.blade.php ENDPATH**/ ?>