<?php $__env->startSection('position'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">نمایش اهدا</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">خانه</a></li>
                <li class="breadcrumb-item active">نمایش اهدا</li>
            </ol>
        </div><!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .dt-buttons {
            float: left;
            padding: 10px;
        }

        .dt-buttons button {
            margin: 3px;
        }
    </style>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title d-inline"><?php echo e($data->title); ?>

                    </h3>
                    <div class="text-left  d-inline" style="float: left">
                        <span><?php echo e($data->date); ?></span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            تعداد نیازمندان :<?php echo e(\App\Models\SendNeedy::whereSendId($data->id)->count()); ?>


                        </div>
                        <div class="col-4">
                            لیست منابع غیر نقدی
                            <ul>
                                <?php $__currentLoopData = \App\Models\SendDetails::where([['send_id',$data->id],['Source_type',2]])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="pr-2">
                                        <?php echo e(\App\Models\Donations::whereId($item->Source_id)->first()->title); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-4">
                            منابع نقدی استفاده شده :
                            <?php echo e(number_format(\App\Models\Receipt::whereIn('id',\App\Models\SendDetails::where([['send_id',$data->id],['Source_type',1]])->get('Source_id'))->sum('amount'))); ?>

                            ریال
                        </div>

                    </div>
                    <hr>

                    <div class="row">
                        <div class="col-6">
                            لیست مستندات :
                            <ul>
                                <?php $__currentLoopData = \App\Models\SendFile::whereSendId($data->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="pr-2">
                                        <a href="<?php echo e(url($l->file)); ?>" target="_blank">
                                            فایل شماره <?php echo e($i+1); ?>

                                        </a>
                                    </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-6">
                            لیست خیرین :
                            <ul>
                                <?php $__currentLoopData = \App\Models\SendDetails::where([['send_id',$data->id],['Source_type',2]])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="pr-2">
                                        <?php echo e(\App\Models\Donator::whereId( \App\Models\Donations::whereId($item->Source_id)->first()->donator_id)->first()->name); ?>

                                        -
                                        کمک غیر نفدی
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = \App\Models\SendDetails::where([['send_id',$data->id],['Source_type',1]])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="pr-2">
                                        <?php echo e(\App\Models\Donator::whereId(\App\Models\Receipt::whereId($item->Source_id)->first()->donator_id)->first()->name); ?>

                                        -
                                        کمک نقدی
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <hr>
                    <div class="col-12">
                        <h6>
                            توضیحات
                        </h6>
                        <div class="p-2">
                            <?php echo $data->description; ?>

                        </div>
                    </div>
                    <hr>
                    <div class="col-12">
                        <h6>
                            مبلغ
                            <?php echo e(number_format($data->extera_money)); ?> ریال  بصورت مازاد استفاده شد
                        </h6>
                        <div class="p-2">
                            <?php echo $data->extera_description; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('donator.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mrgod\Desktop\ponisha\hamdeli\resources\views/donator/send/show.blade.php ENDPATH**/ ?>