<?php $__env->startSection('position'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">ثبت اهدا</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="<?php echo e(route('adminPanel')); ?>">خانه</a></li>
                <li class="breadcrumb-item active">ثبت اهدا</li>
            </ol>
        </div><!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .dt-buttons {
            float: left;
            padding: 10px;
        }

        .dt-buttons button {
            margin: 3px;
        }
    </style>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">ثبت اهدا
                    </h3>

                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <form action="<?php echo e(route('send.update',$data->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="form-group w-100">
                            <label for="recipient-name" class="col-form-label text-right">عنوان :</label>
                            <input type="text" class="form-control w-100" id="recipient-name" name="title"
                                   value="<?php echo e($data->title); ?>" required>
                        </div>
                        <br>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <span style="">نیازمندان:</span>
                                <select class="js-example-basic-multiple form-control" name="needy[]"
                                        multiple="multiple">
                                    <?php $__currentLoopData = \App\Models\Needy::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($g['id']); ?>" <?php echo e(\App\Models\SendNeedy::where([['send_id',$data->id],['needie_id',$g['id']]])->count()>0 ? "selected":''); ?>><?php echo e($g['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <span style=""> منابع:</span>
                                <select class="js-example-basic-multiple form-control" name="resource[]"
                                        multiple="multiple">
                                    <?php $__currentLoopData = \App\Models\Donations::where('status','!=',-1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e('d-'.$g['id']); ?>" <?php echo e(\App\Models\SendDetails::where([['send_id',$data->id],['source_type',2],['Source_id',$g['id']]])->count()>0 ? "selected" :""); ?>>
                                            (<?php echo e($g['title']); ?>)
                                            خیر
                                            <?php echo e(\App\Models\Donator::whereId($g['donator_id'])->first()->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = \App\Models\Receipt::where('status','!=',-1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e('m-'.$g['id']); ?>" <?php echo e(\App\Models\SendDetails::where([['send_id',$data->id],['source_type',1],['Source_id',$g['id']]])->count()>0 ? "selected" :""); ?>>
                                            <?php echo e(number_format($g['amount'])); ?>

                                            ریال
                                            خیر
                                            <?php echo e(\App\Models\Donator::whereId($g['donator_id'])->first()->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="chilename2" class="col-form-label text-right">تاریخ :</label>
                                    <input type="text" required class="form-control" value="<?php echo e($data->date); ?>"
                                           id="chilename2"
                                           name="date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <label>تصاویر و فایل های اهدا :</label>

                                    <input type="file" name="file[]" class="custom-file-input"
                                           onchange="document.getElementById('lablefile').innerHTML ='فایل انتخاب شد !'"
                                           id="exampleInputFile"
                                           multiple>
                                    <label class="custom-file-label" id="lablefile" for="exampleInputFile"
                                           style="top: 37px;">انتخاب
                                        فایل</label>
                                </div>
                            </div>
                            <div class="form-group w-100">
                                <label for="status" class="col-form-label text-right">توضیحات کامل :</label>
                                <textarea class="form-control w-100" id="status" name="description" required><?php echo e($data->description); ?>

                                </textarea>
                            </div>
                        </div>
                        <div class="col-2">
                            <button type="submit" class="btn btn-success">
                                ذخیره
                            </button>
                        </div>
                    </form>
                    <hr>
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>فایل</th>
                            <th>عملیات</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = \App\Models\SendFile::whereSendId($data->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td>
                                    <a href="<?php echo e(url($l->file)); ?>" target="_blank">
                                        فایل شماره <?php echo e($i+1); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('file.delete',$l->id)); ?>" class="btn btn-sm btn-danger">
                                        حذف این مورد
                                    </a>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('Adminasset/dist/js/persian-date.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Adminasset/dist/js/persian-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Adminasset/plugins/select2/select2.full.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.normal-example').persianDatepicker({
                format: 'YYYY/MM/DD',
            });

            $('.js-example-basic-single').select2({
                theme: 'bootstrap4',
                width: 'resolve'
            });
            $('.js-example-basic-multiple').select2();

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mrgod\Desktop\ponisha\hamdeli\resources\views/admin/send/edit.blade.php ENDPATH**/ ?>